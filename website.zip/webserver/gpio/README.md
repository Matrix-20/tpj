# PiGpioWebServer
Raspberry Pi webserver to control GPIO using Node JS

Refer to "GPIO Webserver for Raspbery Pi.pdf" for install procedure.

You tube video at https://youtu.be/TVxQROFPjy0

August 22, 2021: Added updated documentation for the Raspberry Pi Zero and troubleshotting infomation
